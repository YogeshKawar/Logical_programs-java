package Conditional_Statement;

public class Example_Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		switch("Idle"){
			case "Uttapa" :{
				System.out.println("On Monday");
				break;
				
			}
			case "Idle" :{
				System.out.println("On Tuesday");
				break;
			}
			case "vadapav" :{
				System.out.println("On Saturday" );
				break;
			}
			default:
				System.out.println("No Chatani");
		}
	}

}
