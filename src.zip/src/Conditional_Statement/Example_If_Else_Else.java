package Conditional_Statement;

public class Example_If_Else_Else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks = 60;
		if(marks>=65)
		{
			System.out.println("Distinction");
		}
		else if(marks>=50)
		{
			System.out.println("First Class");
		}
		else if(marks>=40)
		{
			System.out.println("Second class");
		}
		else if(marks>=35)
		{
			System.out.println("Pass Class");
		}
		else
		{
			System.out.println("fail");
		}
	}

}
