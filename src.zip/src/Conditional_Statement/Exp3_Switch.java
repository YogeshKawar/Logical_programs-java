package Conditional_Statement;

public class Exp3_Switch {
	public static void main(String[] args) {
		String a="Jun";
		switch(a) {
		case("Jan"):
			System.out.println("Jan month print");
			break;
			
		case("Feb"):
			System.out.println("Feb month print");
			break;
		
		case("Mar"):
			System.out.println("Mar month print");
			break;
			
		case("April"):
			System.out.println("April month print");
			break;
			
		case("May"):
			System.out.println("May month print");
			break;
			
		case("Jun"):
			System.out.println("Jun month print");
			break;
			
		case("July"):
			System.out.println("July month print");
			break;
			
		case("Aug"):
			System.out.println("Aug month print");
			break;
			
		case("Sept"):
			System.out.println("Sept month print");
			break;
			
		case("Oct"):
			System.out.println("Oct month print");
			break;
			
		case("Nov"):
			System.out.println("Nov month print");
			break;
			
		case("Dec"):
			System.out.println("Dec month print");
			break;
	}

}

}