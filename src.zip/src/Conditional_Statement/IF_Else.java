package Conditional_Statement;

public class IF_Else {
	public static void main(String[] args) {
		int a=5;
		if(a>4)
		{
			System.out.println("hi");
		}
		else
		{
			System.out.println("hello");
		}
	}

}
