package Conditional_Statement;

public class If_Statement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (3>2)
		{
			System.out.println("hi");
		}
	}

}
