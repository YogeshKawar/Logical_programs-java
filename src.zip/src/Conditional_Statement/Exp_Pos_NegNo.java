package Conditional_Statement;

public class Exp_Pos_NegNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no=0;
		if(no>0)
		{
			System.out.println("no. is positive");
		}
		else if(no<0)
		{
			System.out.println("no. is negative");
		}
		else
		{
			System.out.println("No is zero");
		}
	}

}
