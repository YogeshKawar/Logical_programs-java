package Conditional_Statement;

public class Example_If_Else {

	public static void main(String[] args) {
		int personAge = 19;
		if(personAge >= 18)
		{
			System.out.println("Person is eligible for license");
		}
		else
		{
			System.out.println("person is not eligible for license");
		}
	}
}
