package Conditional_Statement;

public class exp2_switch {
	public static void main(String[] args)
	{
		char ch='A';
		switch (ch) {
		case('a'):
			System.out.println("vowel - a");
			break;
		case('e'):
			System.out.println("vowel - e");
			break;
		case('i'):
			System.out.println("vowel - i");
			break;
		case('o'):
			System.out.println("vowel - o");
			break;
		case('u'):
			System.out.println("vowel - u");
			break;
		default:
			System.out.println("No vowels");
			
		}
	}

}
