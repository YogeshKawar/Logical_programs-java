package Conditional_Statement;

public class switchEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch='a';
		switch(ch) {
		case('e'):
			System.out.println("Vowel is :e");
			break;
			
		case('a'):
			System.out.println("Vowel is:a");
			break;
			
		case('i'):
			System.out.println("Vowel is :i");
			break;
			
		case('o'):
			System.out.println("Vowel is :o");
			break;
			
		case('u'):
			System.out.println("Vowel is : u");
			break;
			
		default:
			System.out.println("Defualt value");
			
		}
		System.out.println("Hiiii, Im out of switch loop");
	}

}
