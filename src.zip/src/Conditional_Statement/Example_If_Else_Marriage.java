package Conditional_Statement;

public class Example_If_Else_Marriage {
	public static void main(String[] args) {
		int boyAge = 23;
		int girlAge = 19;
		if(boyAge >=21 && girlAge>=18)
		{
			System.out.println("Eligible for Marriage");
		}
		else
		{
			System.out.println("Not Eligible for Marrige");
		}
	}

}
