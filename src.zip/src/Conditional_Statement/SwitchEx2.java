package Conditional_Statement;

public class SwitchEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Shourya";
		
		switch(str) {
		
		case ("asha"):
			System.out.println("HIiiii, Im Asha");
			break;
			
		case("Dipali"):
			System.out.println("Hiiiii, Im Dipali");
			break;
			
		case("Shourya"):
			System.out.println("Hiiiii,Im Shourya");
			break;
			
		default:
			System.out.println("IM from default block");
		}
	}

}
