package Abstract_Class;

public class ClassMethodImpl extends ClassAbstract{
public void m2() {
	System.out.println("MEthod Implementation of m2");
}
}
