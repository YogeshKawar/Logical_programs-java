package Abstract_Class;

public class DemoCallClass {
public static void main(String[] args) {
	AbstractImplDemo s=new AbstractImplDemo();
	s.Add();
	s.mul();
}
}
