package Abstract_Class;

abstract public class AbstractClassDemo {
abstract public void Add();
public void mul() {
	System.out.println("Multication of 10 * 20 is :" +(10*20));
}
}
