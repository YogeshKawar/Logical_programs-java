package Abstract_Class;

public class mainClass {
public static void main(String[] args) {
	ClassMethodImpl c=new ClassMethodImpl();
	c.m1();
	c.m2();
	c.m3();
}
}
