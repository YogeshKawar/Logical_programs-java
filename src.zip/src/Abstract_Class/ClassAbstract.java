package Abstract_Class;

abstract public class ClassAbstract {
public void m1() {
	System.out.println("Hiiii");
}
abstract public void m2();
public void m3() {
	System.out.println("HElloooooo");
}
}
