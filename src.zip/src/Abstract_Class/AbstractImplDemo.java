package Abstract_Class;

public class AbstractImplDemo extends AbstractClassDemo{
public void Add() {
	System.out.println("Addition of 10 + 20 is :" +(10+20));
}
}
