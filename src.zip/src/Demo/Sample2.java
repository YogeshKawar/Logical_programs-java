package Demo;

public class Sample2 {
public static void main(String []args) {
	char ch='A';
	System.out.println(ch);
}
}
