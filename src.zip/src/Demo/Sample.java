package Demo;

public class Sample {
 public static void main(String[] args) {
	String s="Asha";
	System.out.println(s);
	
}
}