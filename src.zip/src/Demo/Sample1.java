package Demo;

public class Sample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int i=100;
      System.out.println(i);
	}

}
