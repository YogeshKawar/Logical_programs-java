package Demo;

public class Sample3 {
public static void main(String []args) {
	long l=234567l;
	double d = 4567.678;
	float f = 7890.78f;
	byte b = 12;
	short s = 567;
	System.out.println(l);
	System.out.println(d);
	System.out.println(f);
	System.out.println(b);
	System.out.println(s);
}
}
