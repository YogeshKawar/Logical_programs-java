//package DAP;

//public class SubClass1 extends SuperClass1, SuperClass2 {
//public void m1()
//{
//	System.out.println("Method from subclass 1");
//}
//}
