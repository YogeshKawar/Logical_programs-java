package DAP;

public class SuperClass2 {
public void m3()
{
	System.out.println("Method from m3");
}
}
