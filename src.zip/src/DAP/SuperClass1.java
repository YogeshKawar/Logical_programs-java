package DAP;

public class SuperClass1 {
public void m2()
{
	System.out.println("Method from Super Class");
}
}
