package Array;

public class Arr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] i=new int[5];
		i[0]=10;
		i[1]=20;
		i[2]=30;
		i[3]=40;
		i[4]=50;
	//	System.out.println(i[1]);
	//	System.out.println(i[5]);
		
		for(int j=0;j<=4;j++)
		{
			System.out.println(i[j]);
		}
	}

}
