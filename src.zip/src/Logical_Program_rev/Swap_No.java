package Logical_Program_rev;

public class Swap_No {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		System.out.println("Before Swapping 'a' is:"+a);
		System.out.println("Before Swapping 'b' is:"+b);
		int c=a;
		a=b;
		b=c;
		System.out.println("After Swapping 'a' is:"+a);
		System.out.println("After Swapping 'b' is:"+b);
	}

}
