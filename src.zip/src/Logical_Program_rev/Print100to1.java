package Logical_Program_rev;

public class Print100to1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=100;i>=1;i--)
		{
			System.out.println(i);
		}
	}

}
