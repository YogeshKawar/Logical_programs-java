package Logical_Program_rev;

public class Print1to100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++)
		{
			System.out.println(i);
		}
	}

}
