package Logical_Program_rev;

public class PrintZtoA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch='Z';ch>='A';ch--)
		{
			System.out.println(ch);
		}
	}

}
