package Logical_Program_rev;

public class PrintAtoZ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch='A';ch<='Z';ch++)
		{
			System.out.println(ch);
		}
	}

}
