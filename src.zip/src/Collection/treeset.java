package Collection;

import java.util.TreeSet;

public class treeset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet ts=new TreeSet();
		ts.add(10);
		ts.add(20);
		ts.add(400);
		ts.add(60);
		System.out.println(ts);
	//	ts.add("Asha");
	//	ts.add("jyoti");
	}

}
