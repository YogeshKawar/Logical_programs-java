package Method_parameter;

public class Method_withparam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addition(20,80);
	}
	public static void addition(int a, int b)
	{
		int c = a+b;
		System.out.println("Addition is : " +c);
	}


}
