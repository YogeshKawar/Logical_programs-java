package Method_parameter;

public class Method_withoutparam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			addition();
		}
		
		public static void addition()
		{
			int a = 10;
			int b=20;
			int c = a+b;
			System.out.println("Addition is : " +c);
		}

	}


