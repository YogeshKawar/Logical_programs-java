package Inheritance;

public class Single_Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Son s=new Son();
		s.mobile();
		s.home();
		s.money();
		s.car();
		System.out.println("Child + Super method invoke");
	//	s.hashCode();
	//	s.toString();
	//	s.notify();
	}

}
