package Inheritance.hirarchicle;

public class Hirarchical_Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Son1 s1=new Son1();
		s1.home();
		s1.SecMobile();
		
		Son2 s2=new Son2();
		s2.home();
		s2.SecLappy();
		
		Son3 s3=new Son3();
		s3.home();
		s3.SecCar();
		
	}

}
