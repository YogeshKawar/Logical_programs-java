package Inheritance.hirarchicle;

public class Son3 extends Father{
	public void SecCar()
	{
		System.out.println("Son having Second hand Car");
	}
}
