package Inheritance.hirarchicle;

public class Son2 extends Father {
	public void SecLappy()
	{
		System.out.println("Son having Second hand Lappy");
	}
}
