package Inheritance.hirarchicle;

public class Son1 extends Father{
	public void SecMobile()
	{
		System.out.println("Son having Second hand Mobile");
	}
}
