package Inheritance.hirarchicle;

public class Father {
	public void home()
	{
		System.out.println("Father having home");
	}

}
