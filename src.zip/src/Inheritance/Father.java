package Inheritance;

public class Father {

	public void home()
	{
		System.out.println("home provided to son");
	}
	public void money()
	{
		System.out.println("Money provided to son");
	}
	public void car()
	{
		System.out.println("car provided to son");
	}

}
