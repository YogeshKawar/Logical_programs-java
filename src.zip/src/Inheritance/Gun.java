package Inheritance;

public class Gun {
public void shootFromParent()
{
	System.out.println("Shooting from Gun");
}
}

