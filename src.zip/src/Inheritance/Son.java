package Inheritance;

public class Son extends Father {
	String name;
	int m;
	Son()
	{
		name="Apple";
	}

	public void mobile()
	{
		System.out.println("Son already have an " +name+ " mobile");
	}

}
