package Inheritance.Multilevel_Inheritance;

public class Exp1_Multilevel_Inheritance {
	public static void main(String[] args) {
		Exp1_Whatsappv3 w=new Exp1_Whatsappv3();
		w.txtMessage();
		w.audioCalling();
		w.videoCalling();
	}
}
