package Inheritance.Multilevel_Inheritance;

public class Exp2_Multilevel_Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exp2_Son e =new Exp2_Son();
		e.grandpapa();
		e.Father();
		e.sonmy();
	}

}
