package Inheritance.Multilevel_Inheritance;

public class Exp1_Whatsappv3 extends Exp1_Whatsappv2{
	public void videoCalling() {
		System.out.println("Video Calling doing");
	}

}
