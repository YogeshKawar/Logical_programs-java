package Inheritance.Multilevel_Inheritance;

public class Exp2_Son extends Exp2_Father{
	public void sonmy() {
		System.out.println("My Son");
	}
}
