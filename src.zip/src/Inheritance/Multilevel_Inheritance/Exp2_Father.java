package Inheritance.Multilevel_Inheritance;

public class Exp2_Father extends Exp2_Grandappa{
	public void Father() {
		System.out.println("my Father");
	}
}
