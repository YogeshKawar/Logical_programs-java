package Inheritance.Multilevel_Inheritance;

public class Exp2_Grandappa {
	public void grandpapa() {
		System.out.println("My grandppa");
	}

}
