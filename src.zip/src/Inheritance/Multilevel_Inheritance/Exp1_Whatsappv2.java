package Inheritance.Multilevel_Inheritance;

public class Exp1_Whatsappv2 extends Exp1_Whatsappv1{
	public void audioCalling() {
		System.out.println("Audio Calling doing");
	}
}
