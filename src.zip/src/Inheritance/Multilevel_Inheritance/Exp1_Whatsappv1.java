package Inheritance.Multilevel_Inheritance;

public class Exp1_Whatsappv1 {
		public void txtMessage() 
		{
			System.out.println("HIII HOW R U");
			
		}
		}

