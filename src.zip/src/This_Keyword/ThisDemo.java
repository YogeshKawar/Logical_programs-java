package This_Keyword;

public class ThisDemo {
public static void main(String[] args) {
	ThisKeyword t=new ThisKeyword();
	t.accessLocalVar();
}
}
