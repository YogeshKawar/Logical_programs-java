package This_Keyword;

public class DemoThisKeywod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		This_Keyword d=new This_Keyword();
		d.access_Variable();
	}

}
