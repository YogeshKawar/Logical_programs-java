package This_Keyword;

public class Student {
String Name = "Asha";
public void getdata()
{
	int rollNo=5;
	System.out.println("Student Name  :" +this.Name);
	System.out.println("Student Roll No. :" +rollNo);
}
}
