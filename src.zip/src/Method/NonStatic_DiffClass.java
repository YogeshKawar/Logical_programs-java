package Method;

public class NonStatic_DiffClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NonStaticCall s=new NonStaticCall();
		System.out.println("Div is :"+s.div(500, 20));
	}

}
