package Method;

public class NonStat_RegularMethod {

	public void m1()
	{
		System.out.println("non static m1 method call from diff class");
	}
	public void m2()
	{
		System.out.println("non static m2 method call from diff class");
	}
	public void m3()
	{
		System.out.println("non static m3 method call from diff class");
	}
	public void m4()
	{
		System.out.println("non static m4 method call from diff class");
	}
	}
