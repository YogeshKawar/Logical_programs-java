package Method;

public class Regular_Method {

	public static void m1()
	{
		System.out.println("Static m1 method call from different class");
	}
	public static void m2()
	{
		System.out.println("Static m2 method call from different class");
	}
	public static void m3()
	{
		System.out.println("Static m3 method call from different class");
	}
	public static void m4()
	{
		System.out.println("Static m4 method call from different class");
	}

}
