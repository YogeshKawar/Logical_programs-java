package Method;

public class StaticMethod_SameClass {
	
	public static void add()
	{
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println("Addition is :"+c);
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		add();
	}

}
