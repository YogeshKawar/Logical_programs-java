package Method;

public class NonStatMethod_DiffClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NonStat_RegularMethod ns = new NonStat_RegularMethod();
		ns.m1();
		ns.m2();
		ns.m3();
		ns.m4();
		
	}

}
