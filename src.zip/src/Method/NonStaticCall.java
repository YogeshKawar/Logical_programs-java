package Method;

public class NonStaticCall {
	public int div(int x, int y) {
		int z=x/y;
		return z;
	}
}
