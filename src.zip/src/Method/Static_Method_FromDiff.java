package Method;

public class Static_Method_FromDiff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Regular_Method.m1();
		Regular_Method.m2();
		Regular_Method.m3();
		Regular_Method.m4();
	}
	
}
