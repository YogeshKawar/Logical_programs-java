package Method;

public class Static_MethodPractice {
	static int i=10;
	static int j=20;
    public static void addition()
    {
    	int c=i+j;
    	System.out.println(c);
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
     addition();
}}
