package Method;

public class Static_Method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		m1();
		m2();
		m3();
		m4();
	}
	public static void m1()
	{
		System.out.println("Static m1 method call from same class");
	}
	public static void m2()
	{
		System.out.println("Static m2 method call from same class");
	}
	public static void m3()
	{
		System.out.println("Static m3 method call from same class");
	}
	public static void m4()
	{
		System.out.println("Static m4 method call from same class");
	}

}
