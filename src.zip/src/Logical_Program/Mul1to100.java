package Logical_Program;

import java.util.Scanner;

public class Mul1to100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc=new Scanner(System.in);
		//System.out.println("Enter No. :");
		//int num=sc.nextInt();
		int mul=1;
		for(int i=1;i<=10;i++)
		{
			mul=mul*i;
		}
		System.out.println("Mul from 1 to 10: " +mul);
	}

}
