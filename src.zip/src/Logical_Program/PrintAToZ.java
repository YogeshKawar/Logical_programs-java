package Logical_Program;

public class PrintAToZ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch='A';ch<='Z';ch++)
		{
			System.out.println(ch);
		}
	}

}
