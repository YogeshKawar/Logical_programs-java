package Logical_Program;

public class sum1to100_rep1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		int sum=0;
		for(int i=1;i<=num;i++)
		{
			sum=sum+i;
		}
		System.out.println(sum);
	}

}
