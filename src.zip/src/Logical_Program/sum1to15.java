package Logical_Program;

public class sum1to15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=15;
		int sum=0;
		for(int i=1;i<=num;i++)
		{
			sum=sum+i;
		}
		System.out.println("Sum is:"+sum);
	}

}
