package Logical_Program;

public class PrintA_Z {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char a='A'; a<='Z';a++)
		{
			System.out.println(" " + a);
		}
		
		
		for(char ch='a'; ch<='z';ch++)
		{
			System.out.println(" " +ch);
		}
	}

}
