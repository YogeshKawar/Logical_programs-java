package Logical_Program;

public class Multiplication1to10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=10;
		int mul=1;
		for(int i=1;i<=num;i++)
		{
			mul=mul*i;
			System.out.println(mul);
			
		}
		System.out.println("Multiplication from 1 to 10 is :" +mul);
	}

}
