package Logical_Program;

public class Print1to100rev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=100;i++)
		{
			System.out.println("1 To 100:"+i);
		}
	}

}
