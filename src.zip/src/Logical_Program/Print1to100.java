package Logical_Program;

public class Print1to100 {
	public static void main(String[] args) {
		int i=1;
		while(i<=100)
		{
			System.out.print(" " +i++);
		}
		
		//Using for loop
		System.out.println();
		
		for(int j=1;j<=100;j++)
		{
			System.out.print(" "+j);
		}
		
		
	}

}
