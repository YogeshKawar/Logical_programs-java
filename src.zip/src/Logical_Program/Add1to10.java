package Logical_Program;

import java.util.Scanner;

public class Add1to10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc=new Scanner(System.in);
		//System.out.println("Enter No. :");
		//int num=sc.nextInt();
		int add=0;
		for(int i=1;i<=10;i++)
		{
			add=add+i;
		}
		System.out.println("Addition of no from 1 to 10 : " +add);
	}

}
