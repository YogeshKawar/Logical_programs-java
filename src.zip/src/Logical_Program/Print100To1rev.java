package Logical_Program;

public class Print100To1rev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=100;i>=1;i--)
		{
			System.out.println("Rev No. from 100 to 1:"+i);
		}
	}

}
