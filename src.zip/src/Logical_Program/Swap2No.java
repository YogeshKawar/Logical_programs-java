package Logical_Program;

public class Swap2No {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		System.out.println("Before Swapping : a is :"+a+ " & b is :" +b);
		int c=a;
		a=b;
		b=c;
		System.out.println("After Swapping No. a is :"+a+ " & b is:" +b);
	}

}
