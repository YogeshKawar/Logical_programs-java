package Logical_Program;

public class Swapping2No {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=12;
		int y=24;
		int z=x;
		x=y;
		y=z;
		System.out.println("After Swapping : x is :" +x);
		System.out.println("After swapping : y is :" +y);
	}

}
