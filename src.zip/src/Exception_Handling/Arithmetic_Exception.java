package Exception_Handling;

public class Arithmetic_Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=1;
int b=0;

try {
	int c=a/b;
}
catch(ArithmeticException ae) {
	System.out.println("Enter valid denomenator");
}
	}

}
