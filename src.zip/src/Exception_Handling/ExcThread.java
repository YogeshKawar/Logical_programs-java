package Exception_Handling;

public class ExcThread {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("hiiiiii");
		Thread.sleep(5000);
		System.out.println("hellooooooooo");
	}

}
