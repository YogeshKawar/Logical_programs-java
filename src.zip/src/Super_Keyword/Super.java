package Super_Keyword;

public class Super {
	int a=100;

}
