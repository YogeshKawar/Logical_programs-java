package Super_Keyword;

public class Main_SuperCall {
public static void main(String[] args) {
	SubClass s=new SubClass();
	s.accessSuperVar();
}
}
