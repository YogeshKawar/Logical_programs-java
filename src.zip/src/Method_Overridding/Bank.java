package Method_Overridding;

public class Bank {
 int getRateOfInterest()
	{
		return 0;
	}

}
