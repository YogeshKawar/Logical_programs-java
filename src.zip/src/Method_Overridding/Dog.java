package Method_Overridding;

public class Dog extends Animal{
	public void animalsTalk()
	{
		System.out.println("bhow bhow");
	}

}
