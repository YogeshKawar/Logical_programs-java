package Method_Overridding;

public class Son2 extends Father{
	public void Car()
	{
		System.out.println("Son having its own Car");
	}

}
