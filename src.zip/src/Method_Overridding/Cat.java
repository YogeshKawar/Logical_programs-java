package Method_Overridding;

public class Cat extends Animal{
	public void animalsTalk()
	{
		System.out.println("Mew Mew");
	}
}
