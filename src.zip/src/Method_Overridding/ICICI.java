package Method_Overridding;

public class ICICI extends Bank{
	int getRateOfInterest()
	{
		return 10;
	}

}
