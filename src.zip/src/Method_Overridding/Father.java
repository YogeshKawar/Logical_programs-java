package Method_Overridding;

public class Father {

}
