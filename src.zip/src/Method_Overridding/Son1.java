package Method_Overridding;

public class Son1 extends Father{
	public void Car()
	{
		System.out.println("Son having its own Car");
	}
}
