package Method_Overridding;

public class Father_Data {
	public void Home()
	{
		System.out.println("Father having its own home");
	}
	public void Car()
	{
		System.out.println("Father having its own car");
	}
}
