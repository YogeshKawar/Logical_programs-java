package Method_Overridding;

public class Animal {
	public void animalsTalk()
	{
		System.out.println("Animal Talking");
	}

}
