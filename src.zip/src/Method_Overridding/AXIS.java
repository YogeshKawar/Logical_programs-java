package Method_Overridding;

public class AXIS extends Bank {
	int getRateOfInterest()
	{
		return 8;
	}

}
