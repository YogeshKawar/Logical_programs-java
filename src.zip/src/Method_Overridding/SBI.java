package Method_Overridding;

public class SBI extends Bank{
	int getRateOfInterest()
	{
		return 9;
	}

}
