package Casting;

public class ExplicitCasting {
public static void main(String[] args) {
	double b=8.50d;
	int a=(int)b;
	System.out.println("Explicit Casting:" +a);
}
}
