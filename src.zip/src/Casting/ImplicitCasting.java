package Casting;

public class ImplicitCasting {
public static void main(String[] args) {
	int a=50;
	double d=a;
	System.out.println("Double data is :" +d);
}
}
