package Interface;

public class ULC_Class {
public static void main(String[] args) {
	ImplementClass i=new ImplementClass();
	i.m1();
	i.m2();
	i.m3();
	i.m4();
}
}
