package Interface;

public interface I2_Interface {
void m3();
void m4();
}
