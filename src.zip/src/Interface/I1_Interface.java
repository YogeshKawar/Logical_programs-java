package Interface;

public interface I1_Interface {
void m1();
void m2();
}
