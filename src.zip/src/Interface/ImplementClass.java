package Interface;

public class ImplementClass implements I1_Interface, I2_Interface{
public void m1()
{
	System.out.println("IMplementation from I1");
}
public void m2()
{
	System.out.println("IMplementation from I1");
}
public void m3()
{
	System.out.println("IMplementation from I2");
}
public void m4()
{
	System.out.println("IMplementation from I2");
}
}