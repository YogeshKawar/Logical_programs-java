package Constructor;

public class OddNo1 {
	int n;
	public void OddNo()
	{
		for (int i=1; i<=n; i+=2)
		{
			System.out.println("Odd No is :"+i);
		}
	}
}
