package Constructor;

public class OddNo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OddNo1 o = new OddNo1();
		o.n=10;
		o.OddNo();
	}

}
