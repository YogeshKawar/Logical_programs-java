package Constructor;

public class Gun {

		String gunName;
		int noOfBullet;
		public void shoot()	{
		for(int i=1; i<=noOfBullet;i++)
		{
			System.out.println("Bullet Fire");
		}
		}

}
