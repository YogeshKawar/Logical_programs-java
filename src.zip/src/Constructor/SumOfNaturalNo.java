package Constructor;

public class SumOfNaturalNo {
	int c;
	int sum;
	public void sumOfNumber() {
		for(int i=1; i<=c;i++)
		{
			sum=sum+i;
			
		}
		System.out.println("Sum of Natural No." +sum);
	}

}
