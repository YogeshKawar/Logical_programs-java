package Constructor;

public class EvenNo1 {
	int n;
	public void evenno() {
		for (int i=0; i<=n ;i+=2) {
			System.out.println("Even No:" +i);
		}
	}

}
