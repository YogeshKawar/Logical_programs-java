package Constructor;

public class SumOfNaturalNo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SumOfNaturalNo s=new SumOfNaturalNo();
		s.c=10;
		s.sumOfNumber();
	}

}
