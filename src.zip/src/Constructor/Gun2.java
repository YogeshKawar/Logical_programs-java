package Constructor;

public class Gun2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gun g =new Gun();
		g.gunName ="Ak47";
		g.noOfBullet = 6;
		g.shoot();
		System.out.println("OPeration Completed");

}
}
