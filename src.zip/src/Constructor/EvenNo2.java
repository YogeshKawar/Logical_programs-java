package Constructor;

public class EvenNo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EvenNo1 e= new EvenNo1();
		e.n=20;
		e.evenno();
				
	}

}
