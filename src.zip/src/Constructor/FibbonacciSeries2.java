package Constructor;

public class FibbonacciSeries2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FibbonacciSeries f = new FibbonacciSeries();
		f.n1=0;
		f.n2=1;
		f.c=10;
		f.fbSeries();

	}

}
