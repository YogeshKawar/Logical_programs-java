package Variable;

public class Global_variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
