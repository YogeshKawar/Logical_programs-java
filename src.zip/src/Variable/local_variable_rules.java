package Variable;

public class local_variable_rules {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// rule 1
		
		int i= 20;
		System.out.println(i);
		
		// rules 2
		
		double d ;
		d = 23.45;
		System.out.println(d);
		
		//rule 3
		
	//	float f1;
	//	long f2;
		
		//rule 4 & 5
		
		float f = 2.56f;
		f = 23;
		f = 25;
		
		System.out.println(f);
		
	
	}

}
