package Variable;

public class Local_variable {

	public static void main(String[] args) {
		int i =50;
		System.out.println(i);
	}

}
