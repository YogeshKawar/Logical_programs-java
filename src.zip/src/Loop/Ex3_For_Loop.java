package Loop;

public class Ex3_For_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=10; i>=5;i--) {
			System.out.println(i);
		}
	}

}
