package Loop;

public class Ex4_For_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch='A';ch<='E';ch++) {
			System.out.println(ch);
		}
	}

}
