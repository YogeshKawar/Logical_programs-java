package Loop;

public class Ex5_For_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char ch = 'z'; ch>='u';ch--)
		{
			System.out.println(ch);
		}
	}

}
