package Loop;

public class Ex6_For_Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=1; i <= 100; i++) {
			//System.out.println("Increament Value :" +i);
			System.out.println(i);
		}
	}

}
