package Loop;

public class Ex1_For_Loop {
	public static void main(String[] args) {
		for (int i=1; i <= 5; i++) {
			//System.out.println("Increament Value :" +i);
			System.out.println(i);
		}
	}

}
