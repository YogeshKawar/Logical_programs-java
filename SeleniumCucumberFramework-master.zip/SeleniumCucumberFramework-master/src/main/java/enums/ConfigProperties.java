package enums;

/**
 * @author Sreej
 */
public enum ConfigProperties {

    BROWSER,
    SELENIUMGRIDURL,
    SENDRESULTTOELK,
    RUNMODE,
    ELKURL

}
