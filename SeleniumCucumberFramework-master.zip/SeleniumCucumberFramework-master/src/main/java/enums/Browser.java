package enums;

/**
 * @author Sreej
 */
public enum Browser {

    CHROME,
    EDGE,
    FIREFOX

}
