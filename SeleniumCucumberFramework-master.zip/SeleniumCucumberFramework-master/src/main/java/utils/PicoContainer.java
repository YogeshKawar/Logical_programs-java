package utils;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Sreej
 */
public class PicoContainer {

    public Map<String, Object> dataStore = new HashMap<>();

}
